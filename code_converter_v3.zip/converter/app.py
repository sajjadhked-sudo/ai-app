from flask import Flask, request, jsonify, send_from_directory
import anthropic
import os

app = Flask(__name__, static_folder='static')

@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

@app.route('/convert', methods=['POST'])
def convert():
    data = request.json
    api_key = data.get('apiKey', '').strip()
    input_code = data.get('inputCode', '').strip()
    from_lang = data.get('fromLang', '')
    to_lang = data.get('toLang', '')
    add_comments = data.get('addComments', True)
    optimize = data.get('optimize', True)
    explain = data.get('explain', True)
    add_tests = data.get('addTests', False)

    if not api_key:
        return jsonify({'success': False, 'error': 'أدخل مفتاح API'})
    if not input_code:
        return jsonify({'success': False, 'error': 'أدخل الكود المراد تحويله'})
    if from_lang == to_lang:
        return jsonify({'success': False, 'error': 'اللغتان متطابقتان!'})

    prompt = f"""أنت خبير محترف في تحويل الكود بين لغات البرمجة، متخصص في لغات التداول مثل Pine Script وMQL5 وMQL4.

حوّل الكود التالي من {from_lang} إلى {to_lang} بدقة 100%.

الكود المصدر ({from_lang}):
```
{input_code}
```

المتطلبات:
1. حافظ على نفس المنطق والوظيفة بالكامل
2. استخدم أفضل الممارسات في {to_lang}
3. تأكد أن الكود يعمل بشكل صحيح
{"4. أضف تعليقات واضحة بالعربية لشرح كل جزء" if add_comments else ""}
{"5. حسّن الكود لأفضل أداء ممكن" if optimize else ""}
{"6. أضف اختبارات بسيطة" if add_tests else ""}
{"اشرح الفروق الرئيسية أولاً ثم أعطني الكود." if explain else "أعطني الكود المحوّل فقط."}"""

    try:
        client = anthropic.Anthropic(api_key=api_key)
        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            messages=[{"role": "user", "content": prompt}]
        )
        return jsonify({'success': True, 'result': response.content[0].text})
    except anthropic.AuthenticationError:
        return jsonify({'success': False, 'error': '❌ مفتاح API غير صحيح'})
    except anthropic.RateLimitError:
        return jsonify({'success': False, 'error': '⏳ تجاوزت الحد، انتظر قليلاً'})
    except Exception as e:
        return jsonify({'success': False, 'error': f'خطأ: {str(e)}'})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=False)
